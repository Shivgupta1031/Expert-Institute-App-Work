package com.devshiv.expertinstitute.utils

interface MyOnClickListener {
    fun onClick(data: Any)
}