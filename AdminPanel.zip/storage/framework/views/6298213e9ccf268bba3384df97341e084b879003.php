

<?php $__env->startSection('css'); ?>
    <style>
        @media (min-width: 200px) and (max-width: 420px) {

            .btn-sm,
            .btn {
                font-size: 0.75rem;
                line-height: 1.5;
                padding: 0.1rem 0.3rem;
                border-radius: 0.25rem;
            }

            .btn:not(:last-child) {
                margin-right: 0.2rem;
            }
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="header bg-primary pb-6">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h2 text-white d-inline-block mb-0">Settings</h6>
                    </div>
                </div>
                <div id="noticeAlert">
                    <?php if(\Session::has('message')): ?>
                        <?php if(\Session::has('success') && \Session::get('success')): ?>
                            <div class="alert-success alert alert-dismissible fade show w-100 mr-3" data-auto-dismiss="3000"
                                role="alert">
                                <span class="h4 text-white"> <i class="fas fa-check mr-2"></i><?php echo \Session::get('message'); ?></span>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                        aria-hidden="true">&times;</span></button>
                            </div>
                        <?php else: ?>
                            <div class="alert-danger alert alert-dismissible fade show w-100 mr-3" data-auto-dismiss="3000"
                                role="alert">
                                <span class="h4 text-white"> <i class="fas fa-check mr-2"></i><?php echo \Session::get('message'); ?></span>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                        aria-hidden="true">&times;</span></button>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>


    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-xl-12 mt-7">
                <form method="post" action="<?php echo e(route('saveSettings')); ?>">
                    <?php echo csrf_field(); ?>
                    Admob App ID
                    <div class="input-group mb-3">
                        <input type="text" name="admob_app_id" class="form-control" aria-label="admob_app_id"
                            aria-describedby="basic-addon1" value="<?php echo e($data['admob_app_id']); ?>">
                    </div>
                    Admob Banner ID
                    <div class="input-group mb-3">
                        <input type="text" name="admob_banner_id" class="form-control" aria-label="admob_banner_id"
                            aria-describedby="basic-addon1" value="<?php echo e($data['admob_banner_id']); ?>">
                    </div>
                    Admob Interstitial ID
                    <div class="input-group mb-3">
                        <input type="text" name="admob_interstitial_id" class="form-control"
                            aria-label="admob_interstitial_id" aria-describedby="basic-addon1"
                            value="<?php echo e($data['admob_interstitial_id']); ?>">
                    </div>
                    Contact Email
                    <div class="input-group mb-3">
                        <input type="text" name="contact_email" class="form-control" aria-label="contact_email"
                            aria-describedby="basic-addon1" value="<?php echo e($data['contact_email']); ?>">
                    </div>
                    Privacy Policy
                    <div class="input-group mb-3">
                        <input type="text" name="privacy_policy" class="form-control" aria-label="privacy_policy"
                            aria-describedby="basic-addon1" value="<?php echo e($data['privacy_policy']); ?>">
                    </div>
                    FCM Server Key
                    <div class="input-group mb-3">
                        <input type="text" name="fcm_server_key" class="form-control" aria-label="fcm_server_key"
                            aria-describedby="basic-addon1" value="<?php echo e($data['fcm_server_key']); ?>">
                    </div>
                    Admin Panel Email
                    <div class="input-group mb-3">
                        <input type="text" name="email" class="form-control" aria-label="Email"
                            aria-describedby="basic-addon1" value="<?php echo e($data['email']); ?>">
                    </div>
                    Admin Panel Password
                    <div class="input-group mb-3">
                        <input type="text" name="password" class="form-control" aria-label="Password"
                            aria-describedby="basic-addon1" value="<?php echo e($data['password']); ?>">
                    </div>

                    <button type="submit" class="btn btn-primary">Save</button>
                </form>
            </div>
        </div>

        <?php echo $__env->make('adminPanel.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminPanel/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Android Studio Projects\Prem Apps Projects\Dream 11 Guide App\AdminPanel\resources\views/adminPanel/settings.blade.php ENDPATH**/ ?>