<?php $__env->startSection('content'); ?>
    <div class="header bg-primary pb-6">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h2 text-white d-inline-block mb-0">Ebooks</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header border-0">
                        <div id="noticeAlert">
                            <?php if(\Session::has('message')): ?>
                                <?php if(\Session::has('success') && \Session::get('success')): ?>
                                    <div class="alert-success alert alert-dismissible fade show w-100 mr-3"
                                        data-auto-dismiss="3000" role="alert">
                                        <span class="h4 text-white"> <i
                                                class="fas fa-check mr-2"></i><?php echo \Session::get('message'); ?></span>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                                aria-hidden="true">&times;</span></button>
                                    </div>
                                <?php else: ?>
                                    <div class="alert-danger alert alert-dismissible fade show w-100 mr-3"
                                        data-auto-dismiss="3000" role="alert">
                                        <span class="h4 text-white"> <i
                                                class="fas fa-check mr-2"></i><?php echo \Session::get('message'); ?></span>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                                aria-hidden="true">&times;</span></button>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">Ebooks</h3>
                            </div>
                            <div class="col-lg-6 col-5 text-right">
                                <a class="btn btn-sm btn-primary" href="#" role="button" data-toggle="modal"
                                    data-target="#addEbookItem" aria-haspopup="true" aria-expanded="false">
                                    <i class="fas fa-plus"></i>
                                </a>
                                <div class="modal text-left" id="addEbookItem">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content justify-content-center">
                                            <!-- Modal Header -->
                                            <div class="modal-header">
                                                <h2 class="modal-title">Add Ebook</h2>
                                                <button type="button" class="close" data-dismiss="modal">
                                                    &times;
                                                </button>
                                            </div>

                                            <!-- Modal body -->
                                            <div class="modal-body model">
                                                <form method="post" action="<?php echo e(route('addEbookItem')); ?>"
                                                    id="img-upload-form" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="form-group">
                                                        <label class="h4" for="title">Title</label>
                                                        <input type="text" class="form-control" id="title"
                                                            name="title" />
                                                    </div>
                                                    <label class="h4">Ebook Image</label>
                                                    <div class="custom-file">
                                                        <input type="file" class="custom-file" accept="image/*"
                                                            name="image" id="image" />
                                                        <label class="custom-file-label" id="imageName"
                                                            for="image">Choose
                                                            File</label>
                                                    </div>
                                                    <div class="active-pink-3 active-pink-4 mb-2">
                                                        <input type="text" class="form-control" id="imageUrl"
                                                            name="imageUrl" placeholder="Or Enter File Url" />
                                                    </div>
                                                    <label class="h4">Ebook File (PDF)</label>
                                                    <div class="custom-file">
                                                        <input type="file" class="custom-file" accept=".pdf"
                                                            name="file" id="image2" />
                                                        <label class="custom-file-label" id="imageName2"
                                                            for="image2">Choose File</label>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="h4" for="url">Price</label>
                                                        <input type="text" class="form-control" id="price"
                                                            name="price" />
                                                    </div>
                                                    <button type="submit"
                                                        class="d-flex justify-content-center input-group btn btn-primary text-center">
                                                        Add Ebook
                                                    </button>
                                                </form>
                                            </div>

                                            <!-- Modal footer -->
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                                    Close
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive" id="noticeTable">
                        <!-- Projects table -->
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">S.no</th>
                                    <th scope="col">Image</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <span><?php echo e($loop->index + 1); ?></span>
                                        </td>
                                        <td>
                                            <?php if(strlen($item['image']) == 0): ?>
                                                <img class="img-fluid" src="<?php echo e(asset('images/user.png')); ?>"
                                                    width="60px">
                                            <?php else: ?>
                                                <img class="img-fluid rounded" src="<?php echo e($item['image']); ?>" width="120px">
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="text-wrap h5" style="width: 200px">
                                                <span><?php echo e($item['title']); ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="blue_gradient"><?php echo e($item['price']); ?> INR</span>
                                        </td>
                                        <td>
                                            <a class="btn btn-sm btn-primary" href="#" role="button"
                                                data-toggle="modal" data-target="#editEbookItem<?php echo e($item['id']); ?>"
                                                aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-pen"></i>
                                            </a>
                                            <a class="btn btn-sm btn-primary text-white"
                                                href="<?php echo e(route('deleteEbookItem')); ?>?id=<?php echo e($item['id']); ?>"
                                                role="button" data-toggle="tooltip" data-placement="top"
                                                title="Delete Ebook">
                                                <i class="fa fa-trash"></i>
                                            </a>
                                        </td>

                                        <div class="modal text-left" id="editEbookItem<?php echo e($item['id']); ?>">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content justify-content-center">
                                                    <!-- Modal Header -->
                                                    <div class="modal-header">
                                                        <h2 class="modal-title">Edit Details</h2>
                                                        <button type="button" class="close" data-dismiss="modal">
                                                            &times;
                                                        </button>
                                                    </div>

                                                    <!-- Modal body -->
                                                    <div class="modal-body model">
                                                        <form method="post" action="<?php echo e(route('editEbookItem')); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <input hidden type="text" class="form-control"
                                                                id="id" name="id"
                                                                value="<?php echo e($item['id']); ?>" />
                                                            <div class="form-group">
                                                                <label for="id<?php echo e($item['id']); ?>">Ebook ID</label>
                                                                <input disabled type="text" class="form-control"
                                                                    id="id<?php echo e($item['id']); ?>"
                                                                    name="id<?php echo e($item['id']); ?>"
                                                                    value="<?php echo e($item['id']); ?>" />
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="title<?php echo e($item['id']); ?>">Title</label>
                                                                <input type="text" class="form-control"
                                                                    id="title<?php echo e($item['id']); ?>"
                                                                    name="title<?php echo e($item['id']); ?>"
                                                                    value="<?php echo e($item['title']); ?>" />
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="file<?php echo e($item['id']); ?>">Ebook File</label>
                                                                <input disabled type="text" class="form-control"
                                                                    id="file<?php echo e($item['id']); ?>"
                                                                    name="file<?php echo e($item['id']); ?>"
                                                                    value="<?php echo e($item['file']); ?>" />
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="price<?php echo e($item['id']); ?>">Price</label>
                                                                <input type="text" class="form-control"
                                                                    id="price<?php echo e($item['id']); ?>"
                                                                    name="price<?php echo e($item['id']); ?>"
                                                                    value="<?php echo e($item['price']); ?>" />
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="created<?php echo e($item['id']); ?>">Created On</label>
                                                                <input disabled type="text" class="form-control"
                                                                    id="created<?php echo e($item['id']); ?>"
                                                                    name="created<?php echo e($item['id']); ?>"
                                                                    value="<?php echo e($item['created']); ?>" />
                                                            </div>
                                                            <button type="submit"
                                                                class="d-flex justify-content-center input-group btn btn-primary text-center">
                                                                Update
                                                            </button>
                                                        </form>
                                                    </div>

                                                    <!-- Modal footer -->
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">
                                                            Close
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td>Nothing Found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div id="noticePages" class="card-footer border-0">
                        <div class="row align-items-center align-middle">
                            <div class="col">
                                <?php echo e($data->links('vendor/pagination/bootstrap-4')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('adminPanel.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminPanel/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Android_Studio_Projects\Awari_Academy_App_Fiverr_Client\AdminPanel\resources\views/adminPanel/ebooks.blade.php ENDPATH**/ ?>