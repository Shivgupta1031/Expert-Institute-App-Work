

<?php $__env->startSection('css'); ?>
    <script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
    <style>
        @media (min-width: 200px) and (max-width: 420px) {

            .btn-sm,
            .btn {
                font-size: 0.75rem;
                line-height: 1.5;
                padding: 0.1rem 0.3rem;
                border-radius: 0.25rem;
            }

            .btn:not(:last-child) {
                margin-right: 0.2rem;
            }
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="header bg-primary pb-6">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h2 text-white d-inline-block mb-0">Add Product</h6>
                    </div>
                </div>
                <div id="noticeAlert">
                    <?php if(strlen($message) > 0): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <strong><?php echo e($message); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>


    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-xl-12 mt-5">
                <form method="post" action="/omstar/admin/omstar/home/addNewProduct" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <input type="text" name="name" class="form-control" placeholder="Product Name" aria-label="Name"
                            aria-describedby="basic-addon1">
                    </div>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">₹</span>
                        </div>
                        <input type="text" name="price" class="form-control" placeholder="Price" aria-label="Price">
                    </div>

                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <label class="input-group-text" for="inputGroupSelect01">Select Category</label>
                        </div>
                        <select class="custom-select" name="category" id="inputGroupSelect01">
                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option selected value="<?php echo e($category['category']); ?>"><?php echo e($category['category']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option>Add Category First</option>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">Description</span>
                        </div>
                        <textarea class="form-control" name="description"></textarea>
                        <script>
                            CKEDITOR.replace('description');

                        </script>
                    </div>
                    <br>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" name="isFeatured" id="inlineCheckbox1">
                        <label class="form-check-label" for="inlineCheckbox1">Show As Featured Product</label>
                    </div>
                    <br>
                    <br>
                    <label>Thumbnail</label>
                    <div class="input-group mb-3">
                        <div class="custom-file">
                            <input type="file" name="thumbnail" accept="image/*" class="custom-file-input"
                                id="inputGroupFile01">
                            <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                        </div>
                    </div>
                    <label>Image 1</label>
                    <div class="input-group mb-3">
                        <div class="custom-file">
                            <input type="file" name="image1" accept="image/*" class="custom-file-input"
                                id="inputGroupFile01">
                            <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                        </div>
                    </div>
                    <label>Image 2</label>
                    <div class="input-group mb-3">
                        <div class="custom-file">
                            <input type="file" name="image2" accept="image/*" class="custom-file-input"
                                id="inputGroupFile01">
                            <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                        </div>
                    </div>
                    <label>Image 3</label>
                    <div class="input-group mb-3">
                        <div class="custom-file">
                            <input type="file" name="image3" accept="image/*" class="custom-file-input"
                                id="inputGroupFile01">
                            <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                        </div>
                    </div>
                    <label>Image 4</label>
                    <div class="input-group mb-3">
                        <div class="custom-file">
                            <input type="file" name="image4" accept="image/*" class="custom-file-input"
                                id="inputGroupFile01">
                            <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Product</button>
                </form>
            </div>
        </div>
        <!-- Footer -->
        <footer class="footer mt-4 pt-0">
            <div class="row align-items-center justify-content-lg-between">
                <div class="col-lg-6">
                    <div class="copyright text-center  text-lg-left  text-muted">
                        &copy; 2021 Om Star
                    </div>
                </div>
            </div>
        </footer>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminPanel/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\omstar\resources\views//adminPanel/addProduct.blade.php ENDPATH**/ ?>