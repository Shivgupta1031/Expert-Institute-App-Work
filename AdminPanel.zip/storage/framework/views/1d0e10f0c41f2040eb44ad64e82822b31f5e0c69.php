

<?php $__env->startSection('css'); ?>
    <style>
        @media (min-width: 200px) and (max-width: 420px) {

            .btn-sm,
            .btn {
                font-size: 0.75rem;
                line-height: 1.5;
                padding: 0.1rem 0.3rem;
                border-radius: 0.25rem;
            }

            .btn:not(:last-child) {
                margin-right: 0.2rem;
            }
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="header bg-primary pb-6">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h2 text-white d-inline-block mb-0">Send Notification</h6>
                    </div>
                </div>
                <div id="noticeAlert">
                    <?php if(\Session::has('message')): ?>
                        <?php if(\Session::has('success') && \Session::get('success')): ?>
                            <div class="alert-success alert alert-dismissible fade show w-100 mr-3" data-auto-dismiss="3000"
                                role="alert">
                                <span class="h4 text-white"> <i class="fas fa-check mr-2"></i><?php echo \Session::get('message'); ?></span>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                        aria-hidden="true">&times;</span></button>
                            </div>
                        <?php else: ?>
                            <div class="alert-danger alert alert-dismissible fade show w-100 mr-3" data-auto-dismiss="3000"
                                role="alert">
                                <span class="h4 text-white"> <i class="fas fa-check mr-2"></i><?php echo \Session::get('message'); ?></span>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                        aria-hidden="true">&times;</span></button>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>


    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-xl-12 mt-7">
                <form method="post" action="<?php echo e(route('sendNotification')); ?>"
                    id="img-upload-form" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-2">
                        <input type="text" name="title" class="form-control" placeholder="Enter Notice Title">
                    </div>
                    <div class="input-group mb-2">
                        <input type="text" name="message" class="form-control" placeholder="Enter Message">
                    </div>
                    <div class="input-group mb-2">
                        <input type="text" name="clickUrl" class="form-control" placeholder="Enter Notice Click Url">
                    </div>
                    <div class="custom-file">
                        <input type="file" class="custom-file" accept="image/*" name="image" id="image" />
                        <label class="custom-file-label" id="imageName" for="image">Notification Image</label>
                    </div>
                    <div class="active-pink-3 active-pink-4 mb-2">
                        <input type="text" class="form-control" id="imageUrl" name="imageUrl"
                            placeholder="Or Enter Notification Image Url" />
                    </div>
                    <button type="submit" class="btn btn-primary mt-4">Send</button>
                </form>
            </div>
        </div>

        <?php echo $__env->make('adminPanel.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminPanel/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Android Studio Projects\Prem Apps Projects\Spin win Earning App\AdminPanel\resources\views/adminPanel/notification.blade.php ENDPATH**/ ?>