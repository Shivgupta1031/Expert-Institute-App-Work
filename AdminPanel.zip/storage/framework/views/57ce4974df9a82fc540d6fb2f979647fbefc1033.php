<!doctype html>
<html lang="en">

<head>
    <title><?php echo $__env->yieldContent('title','Om Star'); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    <link rel="icon" href="<?php echo e(asset('images/logo.png')); ?>">

    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-167820841-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-167820841-1');

    </script>

    <?php echo $__env->yieldContent('header'); ?>

</head>

<body>


    <div id="header">
        <nav id="header" class="navbar navbar-expand-md navbar-light">

            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo" class="logoImg">
            <a id="navTitle">Om Star</a>

            <!-- Toggler/collapsibe Button -->
            <button id="header" class="navbar-toggler justify-content-end" type="button" data-toggle="collapse"
                data-target="#collapsibleNavbar">
                <span id="togggleIcon" class="navbar-toggler-icon text-center "></span>
            </button>

            <!-- Navbar links -->
            <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
                <ul id="header" class="navbar-nav justify-content-end text-center">
                    <li class="nav-item">
                        <a class="nav-link" id="navItems" href="/">Home</a>
                    </li>
                    <li class="">
                        <a class="nav-link" id="navItems" href="/shop">Shop</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="navItems" href="/about">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="navItems" href="/contact">Contact Us</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>

    <?php echo $__env->yieldContent('content'); ?>

    <footer class="page-footer font-small blue w-100">

        <!-- Copyright -->
        <div style="position: relative; bottom: 0; width: 100%;"
            class="bg-dark footer-copyright text-center text-white p-4">© 2021 Copyright
            <a href="https://mdbootstrap.com/">Omstar.co.in</a>
        </div>
        <!-- Copyright -->

    </footer>

</body>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
</script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
    integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
</script>
<?php echo $__env->yieldContent('script'); ?>

</html>
<?php /**PATH D:\Laravel\omstar\resources\views/website/main.blade.php ENDPATH**/ ?>