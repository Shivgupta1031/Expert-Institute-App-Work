<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Tattoo Designs - Admin Panel</title>
  <!-- Favicon -->
  <link rel="icon" href="<?php echo e(asset('images/logo.png')); ?>">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
  <!-- Icons -->
  <link rel="stylesheet" href="<?php echo e(asset('adminPanel/vendor/nucleo/css/nucleo.css')); ?>" type="text/css">
  <link rel="stylesheet" href="<?php echo e(asset('adminPanel/vendor/@fortawesome/fontawesome-free/css/all.min.css')); ?>"
    type="text/css">
  <!-- Page plugins -->
  <!-- Argon CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('adminPanel/css/argon.css')); ?>" type="text/css">

  <!--load all styles -->

  <?php echo $__env->yieldContent('css'); ?>

</head><?php /**PATH D:\My Android Studio\Projects\5000+ Tattoo Designs for Men & Women Fiverr Client App\Admin Panel\resources\views/adminPanel/head.blade.php ENDPATH**/ ?>