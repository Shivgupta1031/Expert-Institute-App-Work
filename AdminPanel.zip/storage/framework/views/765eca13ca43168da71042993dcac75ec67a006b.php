

<?php $__env->startSection('content'); ?>
    <div class="header bg-primary pb-6">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h2 text-white d-inline-block mb-0">Settings</h6>
                    </div>
                </div>
                <div id="noticeAlert">
                    <?php if(\Session::has('message')): ?>
                        <?php if(\Session::has('success') && \Session::get('success')): ?>
                            <div class="alert-success alert alert-dismissible fade show w-100 mr-3" data-auto-dismiss="3000"
                                role="alert">
                                <span class="h4 text-white"> <i class="fas fa-check mr-2"></i><?php echo \Session::get('message'); ?></span>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                        aria-hidden="true">&times;</span></button>
                            </div>
                        <?php else: ?>
                            <div class="alert-danger alert alert-dismissible fade show w-100 mr-3" data-auto-dismiss="3000"
                                role="alert">
                                <span class="h4 text-white"> <i class="fas fa-check mr-2"></i><?php echo \Session::get('message'); ?></span>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                        aria-hidden="true">&times;</span></button>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-xl-12 mt-7">
                <form method="post" action="<?php echo e(route('saveSettings')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="h3" for="url">Whatsapp Number</label>
                        <input type="text" class="form-control" id="whatsapp_number" name="whatsapp_number" value="<?php echo e($data['whatsapp_number']); ?>"/>
                    </div>
                    <div class="form-group">
                        <label class="h3" for="url">Telegram Link</label>
                        <input type="text" class="form-control" id="telegram_link" name="telegram_link" value="<?php echo e($data['telegram_link']); ?>"/>
                    </div>
                    <div class="form-group">
                        <label class="h3" for="url">Instagram Link</label>
                        <input type="text" class="form-control" id="instagram_link" name="instagram_link" value="<?php echo e($data['instagram_link']); ?>"/>
                    </div>
                    <div class="form-group">
                        <label class="h3" for="url">Facebook Link</label>
                        <input type="text" class="form-control" id="facebook_link" name="facebook_link" value="<?php echo e($data['facebook_link']); ?>" />
                    </div>
                    <div class="form-group">
                        <label class="h3" for="url">Share App Message</label>
                        <input type="text" class="form-control" id="share_message" name="share_message" value="<?php echo e($data['share_message']); ?>" />
                    </div>
                    <div class="form-group">
                        <label class="h3" for="url">Contact Email</label>
                        <input type="text" class="form-control" id="contact_email" name="contact_email" value="<?php echo e($data['contact_email']); ?>"/>
                    </div>
                    <div class="form-group">
                        <label class="h3" for="url">More App Url</label>
                        <input type="text" class="form-control" id="more_apps_url" name="more_apps_url" value="<?php echo e($data['more_apps_url']); ?>"/>
                    </div>
                    <div class="form-group">
                        <label class="h3" for="url">Privacy Policy Url</label>
                        <input type="text" class="form-control" id="privacy_policy" name="privacy_policy" value="<?php echo e($data['privacy_policy']); ?>"/>
                    </div>
                    <div class="form-group">
                        <label class="h3" for="url">Onesignal App ID</label>
                        <input type="text" class="form-control" id="onesignal_app_id" name="onesignal_app_id" value="<?php echo e($data['onesignal_app_id']); ?>"/>
                    </div>
                    <button type="submit" class="btn btn-primary">Save</button>
                </form>
            </div>
        </div>

        <?php echo $__env->make('adminPanel.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminPanel/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Android_Studio_Projects\Awari_Academy_App_Fiverr_Client\AdminPanel\resources\views/adminPanel/app_settings.blade.php ENDPATH**/ ?>