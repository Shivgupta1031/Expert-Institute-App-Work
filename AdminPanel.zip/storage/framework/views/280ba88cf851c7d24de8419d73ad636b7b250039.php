

<?php $__env->startSection('header'); ?>
    <style>
        .container {
            margin-top: 30px;
        }

        .filter-col {
            padding-left: 10px;
            padding-right: 10px;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="p-4">
        <div class="input-group">
            <input type="text" id="searchProduct" class="form-control" placeholder="Search Products">
            <div class="input-group-append">
                <button onclick="searchProduct()" class="btn btn-primary" type="button">
                    <i class="fa fa-search"></i>
                </button>
            </div>
        </div>
        <br>
        <div class="form-group">
            <label class="filter-col" style="margin-right:0;" for="pref-orderby">Category</label>
            <select id="categorySelect" class="form-control">
                <?php $__empty_1 = true; $__currentLoopData = $data['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option><?php echo e($category['category']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <option>No Category Found</option>
                <?php endif; ?>
            </select>
        </div>

        <div id="products">

            <?php $__empty_1 = true; $__currentLoopData = $data[$data['selectedCat']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($loop->first): ?>
                    <div id="productsConatiner">
                <?php endif; ?>
                <div id="productDiv">
                    <div class="flip-card">
                        <img src="<?php echo e($product['thumbnail']); ?>" id="productImg">
                        <div class="flip-card-inner">
                            <div class="flip-card-front">
                            </div>
                            <div class="flip-card-back">
                                <a href="product/<?php echo e($product['id']); ?>">
                                    <img src="<?php echo e(asset('images/next.png')); ?>"
                                        style="height: 50px; width: 50px; position: absolute;
                                                                                                                                                                                                                                                                                                                                                top: 50%;
                                                                                                                                                                                                                                                                                                                                                transform: translate(-50%, -50%);
                                                                                                                                                                                                                                                                                                                                                left: 50%;
                                                                                                                                                                                                                                                                                                                                                -ms-transform: translate(-50%, -50%);">
                                </a>
                            </div>
                        </div>
                    </div>
                    <br>
                    <label id="productTxt"><?php echo e($product['name']); ?></label>
                    <label id="priceTxt">Price <?php echo e($product['price']); ?> INR</label>
                    <a href="product/<?php echo e($product['id']); ?>"><button id="button">See Details</button></a>

                </div>
                <?php if($loop->last): ?>
            </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h5 class="text-center mt-5 mb-5">No Products Found</h5>
        <?php endif; ?>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        var categorySelect = document.getElementById("categorySelect");
        var productsDiv = document.getElementById("products");
        var data = <?php echo json_encode($data, 15, 512) ?>;

        categorySelect.addEventListener("change", function() {
            document.getElementById("searchProduct").value = "";
            if (data[categorySelect.value].length == 0) {
                productsDiv.innerHTML = `<h5 class="text-center mt-5 mb-5">No Products Found</h5>`;
            } else {
                var newHtml = "";
                for ([i, product] of data[categorySelect.value].entries()) {
                    if (i == 0) {
                        newHtml = '<div id="productsConatiner">';
                    }
                    newHtml += `<div id="productDiv">
                                                                    <div class="flip-card">
                                                                        <img src="` + product['thumbnail'] + `" id="productImg">
                                                                        <div class="flip-card-inner">
                                                                            <div class="flip-card-front">
                                                                            </div>
                                                                            <div class="flip-card-back">
                                                                                <a href="product/` +
                        product['id'] + `">
                                                                                    <img src="<?php echo e(asset('images/next.png')); ?>"
                                                                                        style="height: 50px; width: 50px; position: absolute;
                                                                                                                                                                                                                                                                                                top: 50%;
                                                                                                                                                                                                                                                                                                transform: translate(-50%, -50%);
                                                                                                                                                                                                                                                                                                left: 50%;
                                                                                                                                                                                                                                                                                                -ms-transform: translate(-50%, -50%);">
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <br>
                                                                    <label id="productTxt">` +
                        product['name'] + `</label>
                                                                    <label id="priceTxt">Price ` +
                        product['price'] + ` INR</label>
                                                                    <a href="product/` +
                        product['id'] + `"><button id="button">See Details</button></a>

                                                                </div>`;
                    if (i == (data[categorySelect.value].length - 1)) {
                        newHtml += "</div>";
                    }
                }
                productsDiv.innerHTML = newHtml;
            }
        });

        function searchProduct() {
            searchTerm = document.getElementById("searchProduct").value.toLowerCase();
            console.log(searchTerm);
            if (data[categorySelect.value].length == 0) {
                productsDiv.innerHTML = `<h5 class="text-center mt-5 mb-5">No Products Found</h5>`;
            } else {
                var newHtml = "";
                var serachFound = false;
                for ([i, product] of data[categorySelect.value].entries()) {
                    if (i == 0) {
                        newHtml = '<div id="productsConatiner">';
                    }
                    if (product['name'].toLowerCase().includes(searchTerm) || product['description'].toLowerCase().includes(
                            searchTerm)) {
                        serachFound = true;
                        newHtml += `<div id="productDiv">
                                                                    <div class="flip-card">
                                                                        <img src="` + product['thumbnail'] + `" id="productImg">
                                                                        <div class="flip-card-inner">
                                                                            <div class="flip-card-front">
                                                                            </div>
                                                                            <div class="flip-card-back">
                                                                                <a href="product/` +
                            product['id'] + `">
                                                                                    <img src="<?php echo e(asset('images/next.png')); ?>"
                                                                                        style="height: 50px; width: 50px; position: absolute;
                                                                                                                                                                                                                                                                                                top: 50%;
                                                                                                                                                                                                                                                                                                transform: translate(-50%, -50%);
                                                                                                                                                                                                                                                                                                left: 50%;
                                                                                                                                                                                                                                                                                                -ms-transform: translate(-50%, -50%);">
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <br>
                                                                    <label id="productTxt">` +
                            product['name'] + `</label>
                                                                    <label id="priceTxt">Price ` +
                            product['price'] + ` INR</label>
                                                                    <a href="product/` +
                            product['id'] + `"><button id="button">See Details</button></a>

                                                                </div>`;
                    }
                    if (i == (data[categorySelect.value].length - 1)) {
                        newHtml += "</div>";
                    }
                }
                if (serachFound) {
                    productsDiv.innerHTML = newHtml;
                } else {
                    productsDiv.innerHTML = `<h5 class="text-center mt-5 mb-5">No Products Found</h5>`;
                }
            }
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\omstar\resources\views/website/shop.blade.php ENDPATH**/ ?>