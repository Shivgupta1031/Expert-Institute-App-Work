<nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
        <!-- Brand -->
        <div class="sidenav-header  align-items-center">
            <div class="navbar-brand">
                <img src="<?php echo e(asset('images/logo.png')); ?>" class="navbar-brand-img" alt="...">
            </div>
        </div>
        <div class="navbar-inner">
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="sidenav-collapse-main">
                <!-- Nav items -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <?php if($activePage == 'users'): ?>
                            <a class="nav-link active" href="<?php echo e(route('users')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('users')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-users text-primary"></i>
                        <span class="nav-link-text">Users</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'games'): ?>
                            <a class="nav-link active" href="<?php echo e(route('games')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('games')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-gamepad text-green"></i>
                        <span class="nav-link-text">Games</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'banners'): ?>
                            <a class="nav-link active" href="<?php echo e(route('banners')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('banners')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-images text-red"></i>
                        <span class="nav-link-text">Banners</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'withdrawal_requests'): ?>
                            <a class="nav-link active" href="<?php echo e(route('withdrawal_requests')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('withdrawal_requests')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-wallet text-green"></i>
                        <span class="nav-link-text">Withdrawal Requests</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'notification'): ?>
                            <a class="nav-link active" href="<?php echo e(route('notification')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('notification')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-bell text-red"></i>
                        <span class="nav-link-text">Send Notification</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'settings'): ?>
                            <a class="nav-link active" href="<?php echo e(route('settings')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('settings')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-cog text-primary"></i>
                        <span class="nav-link-text">Settings</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH F:\Android Studio Projects\Prem Apps Projects\Spin win Earning App\AdminPanel\resources\views/adminPanel/sidemenu.blade.php ENDPATH**/ ?>