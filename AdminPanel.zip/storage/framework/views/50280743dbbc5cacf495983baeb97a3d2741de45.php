

<?php $__env->startSection('content'); ?>

    <div id="aboutUsHeading">
        <h1>Contact Us</h1>
    </div>

    <main id="contactMain">
        <div id="mapsDiv">
            <iframe id="map"
                src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3526.5473696550075!2d78.0695477!3d27.8851713!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3974a48f45323035%3A0x1a85d39d8c1794c2!2sStar%20Plus%20Electronics!5e0!3m2!1sen!2sin!4v1590150960911!5m2!1sen!2sin"
                frameborder="0" allowfullscreen="false" aria-hidden="false" tabindex="0"></iframe>
        </div>

        <div id="contactDetailsDiv">
            <label id="titletxt">Office and Works :</label>
            <br> <label id="detailTxt">13/377, Super Star Electronic
                Bhagwan Das Radio Market
                Mamu Bhanja
                Aligarh
                UP, India.</label>

            <br><label id="titletxt">Contact Us : <a id="gmailTxt" href="tel:989-724-4950" target="_blank"> +91
                    9897244950</a></label>
            <br><label id="titletxt">Email : <a id="gmailTxt"
                    href="https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=omstar.co.in@gmail.com" target="_blank">
                    omstar.co.in@gmail.com</a></label>
            <br><label id="titletxt">Toll Free No. :</label>
            <br><label id="detailTxt">9897244950, 11am-6pm, Monday-Sunday (except holidays), Tuesday – Closed.</label>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\omstar\resources\views/contact.blade.php ENDPATH**/ ?>