<?php $__env->startSection('css'); ?>

    <style>
        @media (min-width: 200px) and (max-width: 420px) {

            .btn-sm,
            .btn {
                font-size: 0.75rem;
                line-height: 1.5;
                padding: 0.1rem 0.3rem;
                border-radius: 0.25rem;
            }

            .btn:not(:last-child) {
                margin-right: 0.2rem;
            }
        }

        .w-5 {
            display: none;
        }

        .model {
            height: 100px;
            overflow-y: auto;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="header bg-primary pb-6">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h2 text-white d-inline-block mb-0">Withdrawals</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header border-0">
                        <div id="noticeAlert">
                            <?php if(\Session::has('message')): ?>
                                <?php if(\Session::has('success') && \Session::get('success')): ?>
                                    <div class="alert-success alert alert-dismissible fade show w-100 mr-3"
                                        data-auto-dismiss="3000" role="alert">
                                        <span class="h4 text-white"> <i
                                                class="fas fa-check mr-2"></i><?php echo \Session::get('message'); ?></span>
                                        <button type="button" class="close" data-dismiss="alert"
                                            aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                <?php else: ?>
                                    <div class="alert-danger alert alert-dismissible fade show w-100 mr-3"
                                        data-auto-dismiss="3000" role="alert">
                                        <span class="h4 text-white"> <i
                                                class="fas fa-check mr-2"></i><?php echo \Session::get('message'); ?></span>
                                        <button type="button" class="close" data-dismiss="alert"
                                            aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">Withdrawals</h3>
                            </div>
                            <div class="col-lg-6 col-5 text-right">
                                
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive" id="noticeTable">
                        <!-- Projects table -->
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Username</th>
                                    <th scope="col">Amount</th>
                                    <th scope="col">Points</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Details</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Created On</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <?php echo e($item['id']); ?>

                                        </td>
                                        <td>
                                            <div class="text-wrap" style="width: 100px">
                                                <span><?php echo e($item['username']); ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <?php echo e($item['withdrawal_amount']); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item['withdrawal_points']); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item['title']); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item['details']); ?>

                                        </td>
                                        <td>
                                            <div class="text-wrap" style="width: 100px">
                                                <span><?php echo e($item['status']); ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <?php echo e($item['created']); ?>

                                        </td>
                                        <td>
                                            <a class="btn btn-sm btn-primary" href="#" role="button" data-toggle="modal"
                                                data-target="#editWithdrawalItem<?php echo e($item['id']); ?>" aria-haspopup="true"
                                                aria-expanded="false">
                                                <i class="fas fa-pen"></i>
                                            </a>
                                            <a class="btn btn-sm btn-primary text-white"
                                                href="<?php echo e(route('deleteWithdrawalItem')); ?>?id=<?php echo e($item['id']); ?>"
                                                role="button">
                                                <i class="fa fa-trash"></i>
                                            </a>
                                        </td>
                                        <div class="modal text-left" id="editWithdrawalItem<?php echo e($item['id']); ?>">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content justify-content-center">
                                                    <!-- Modal Header -->
                                                    <div class="modal-header">
                                                        <h2 class="modal-title">Edit Withdrawal</h2>
                                                        <button type="button" class="close" data-dismiss="modal">
                                                            &times;
                                                        </button>
                                                    </div>

                                                    <!-- Modal body -->
                                                    <div class="modal-body model">
                                                        <div class="form-group">
                                                            <label for="status<?php echo e($item['id']); ?>">Status</label>
                                                            <input type="text" class="form-control"
                                                                id="status<?php echo e($item['id']); ?>"
                                                                name="status<?php echo e($item['id']); ?>"
                                                                value="<?php echo e($item['status']); ?>" />
                                                        </div>
                                                    </div>

                                                    <!-- Modal footer -->
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">
                                                            Close
                                                        </button>
                                                        <button type="button" class="btn btn-secondary"
                                                            onclick="editItem('<?php echo e($item['id']); ?>')"
                                                            data-dismiss="modal">Save</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td>Nothing Found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div id="noticePages" class="card-footer border-0">
                        <div class="row align-items-center align-middle">
                            <div class="col">
                                <?php echo e($data->links('vendor/pagination/bootstrap-4')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('adminPanel.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.js"
        integrity="sha512-n/4gHW3atM3QqRcbCn6ewmpxcLAHGaDjpEBu4xZd47N0W2oQ+6q7oc3PXstrJYXcbNU1OHdQ1T7pAP+gi5Yu8g=="
        crossorigin="anonymous"></script>

    <script>
        function editItem(id) {
            var status = document.getElementById('status' + id).value;

            $.ajax({
                url: '<?php echo e(route('editWithdrawalItem')); ?>',
                data: {
                    'id': id,
                    'status': status,
                },
                dataType: 'json',
                success: function(data) {
                    console.log(data);
                    window.location.href = '<?php echo e(route('withdrawal_requests')); ?>';
                }
            });
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminPanel/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Android_Studio_Projects\Play_Miners_Earning_App_Habibkazi\AdminPanel\resources\views/adminPanel/withdrawals.blade.php ENDPATH**/ ?>