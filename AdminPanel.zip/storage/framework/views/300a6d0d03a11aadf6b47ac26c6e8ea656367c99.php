

<?php $__env->startSection('css'); ?>
    <style>
        @media (min-width: 200px) and (max-width: 420px) {

            .btn-sm,
            .btn {
                font-size: 0.75rem;
                line-height: 1.5;
                padding: 0.1rem 0.3rem;
                border-radius: 0.25rem;
            }

            .btn:not(:last-child) {
                margin-right: 0.2rem;
            }
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="header bg-primary pb-6">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h2 text-white d-inline-block mb-0">Settings</h6>
                    </div>
                </div>
                <div id="noticeAlert">
                    <?php if(strlen($message) > 0): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <strong><?php echo e($message); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>


    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-xl-12 mt-7">
                <form method="post" action="/tattoos/home/settings">
                    <?php echo csrf_field(); ?>
                    Facebook Banner Ads ID
                    <div class="input-group mb-3">
                        <input type="text" name="facebook_banner_id" class="form-control" aria-label="facebook_banner_id"
                            aria-describedby="basic-addon1" value="<?php echo e($data['facebook_banner_id']); ?>">
                    </div>
                    Facebook Interstitial Ads ID
                    <div class="input-group mb-3">
                        <input type="text" name="facebook_interstitial_id" class="form-control" aria-label="facebook_interstitial_id"
                            aria-describedby="basic-addon1" value="<?php echo e($data['facebook_interstitial_id']); ?>">
                    </div>
                    <div class="form-check form-check-inline">
                        <label class="form-check-label" for="inlineCheckbox1">Show Ads In App</label>
                        <?php if($data['show_ads']): ?>
                            <input class="form-check-input" checked type="checkbox" name="show_ads" id="inlineCheckbox1">
                        <?php else: ?>
                            <input class="form-check-input" type="checkbox" name="show_ads" id="inlineCheckbox1">
                        <?php endif; ?>
                    </div>
                    <br>
                    <br>
                    Admin Panel Email
                    <div class="input-group mb-3">
                        <input type="text" name="email" class="form-control" aria-label="Email"
                            aria-describedby="basic-addon1" value="<?php echo e($data['email']); ?>">
                    </div>
                    Admin Panel Password
                    <div class="input-group mb-3">
                        <input type="text" name="password" class="form-control" aria-label="Password"
                            aria-describedby="basic-addon1" value="<?php echo e($data['password']); ?>">
                    </div>

                    <button type="submit" class="btn btn-primary">Save</button>
                </form>
            </div>
        </div>
        <!-- Footer -->
        <footer class="footer mt-4 pt-0">
            <div class="row align-items-center justify-content-lg-between">
                <div class="col-lg-6">
                    <div class="copyright text-center  text-lg-left  text-muted">
                        &copy; 2021 Tattoo Designs
                    </div>
                </div>
            </div>
        </footer>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminPanel/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Android Studio\Projects\5000+ Tattoo Designs for Men & Women Fiverr Client App\AdminPanel\resources\views/adminPanel/settings.blade.php ENDPATH**/ ?>