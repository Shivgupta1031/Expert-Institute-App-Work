

<?php $__env->startSection('css'); ?>
    <style>
        @media (min-width: 200px) and (max-width: 420px) {

            .btn-sm,
            .btn {
                font-size: 0.75rem;
                line-height: 1.5;
                padding: 0.1rem 0.3rem;
                border-radius: 0.25rem;
            }

            .btn:not(:last-child) {
                margin-right: 0.2rem;
            }
        }

        .progress {
            position: relative;
            width: 100%;
            height: 20px;
        }

        .bar {
            background-color: #b5076f;
            width: 0%;
            height: 20px;
        }

        .percent {
            position: absolute;
            display: inline-block;
            left: 50%;
            color: #040608;
        }

        .quote-imgs-thumbs {
            background: #eee;
            border: 1px solid #ccc;
            border-radius: 0.25rem;
            margin: 1.5rem 0;
            padding: 0.75rem;
        }

        .quote-imgs-thumbs--hidden {
            display: none;
        }

        .img-preview-thumb {
            background: #fff;
            border: 1px solid #777;
            border-radius: 0.25rem;
            box-shadow: 0.125rem 0.125rem 0.0625rem rgba(0, 0, 0, 0.12);
            margin-right: 1rem;
            max-width: 140px;
            padding: 0.25rem;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="header bg-primary pb-6">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h2 text-white d-inline-block mb-0">Add Product</h6>
                    </div>
                </div>
                <div id="noticeAlert">
                    <?php if(strlen($message) > 0): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <strong><?php echo e($message); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>


    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-xl-12 mt-7">
                <form method="post" action="/adminpanel/panel/home/addImage" id="img-upload-form"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label>Select Images To Upload</label>
                    <div class="input-group mb-3">
                        <div class="custom-file">
                            <input type="file" name="images[]" accept="image/*" class="show-for-sr" multiple
                                id="upload_imgs">
                            <label class="custom-file-label" for="upload_imgs">Choose files</label>
                        </div>
                    </div>
                    <div class="quote-imgs-thumbs quote-imgs-thumbs--hidden" id="img_preview" aria-live="polite"></div>
                    <br>
                    <div class="progress">
                        <div class="bar"></div>
                        <div class="percent">0%</div>
                    </div>
                    <br>
                    <button type="submit" class="btn btn-primary">Add Images</button>
                </form>
            </div>
        </div>
        <!-- Footer -->
        <footer class="footer mt-4 pt-0">
            <div class="row align-items-center justify-content-lg-between">
                <div class="col-lg-6">
                    <div class="copyright text-center  text-lg-left  text-muted">
                        &copy; 2021 Wallpapers
                    </div>
                </div>
            </div>
        </footer>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.js"
    integrity="sha512-n/4gHW3atM3QqRcbCn6ewmpxcLAHGaDjpEBu4xZd47N0W2oQ+6q7oc3PXstrJYXcbNU1OHdQ1T7pAP+gi5Yu8g=="
    crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.3.0/jquery.form.js"
    integrity="sha512-RTxmGPtGtFBja+6BCvELEfuUdzlPcgf5TZ7qOVRmDfI9fDdX2f1IwBq+ChiELfWt72WY34n0Ti1oo2Q3cWn+kw=="
    crossorigin="anonymous"></script>
<script type="text/javascript">
    $(function() {
        $(document).ready(function() {
            var bar = $('.bar');
            var percent = $('.percent');
            $('form').ajaxForm({
                beforeSend: function() {
                    var percentVal = '0%';
                    bar.width(percentVal)
                    percent.html(percentVal);
                },
                uploadProgress: function(event, position, total, percentComplete) {
                    if (percentComplete == 100) {
                        var percentVal = percentComplete + '% Please Wait...';
                    } else {
                        var percentVal = percentComplete + '%';
                    }
                    bar.width(percentVal)
                    percent.html(percentVal);
                },
                complete: function(xhr) {
                    alert('File Has Been Uploaded Successfully');
                    window.location.href = "/adminpanel/panel/home/addImage";
                }
            });

            var imgUpload = document.getElementById('upload_imgs'),
                imgPreview = document.getElementById('img_preview'),
                totalFiles, previewTitle, previewTitleText, img;

            imgUpload.addEventListener('change', previewImgs, false);

            function previewImgs(event) {
                totalFiles = imgUpload.files.length;
                imgPreview.innerHTML = "";

                if (!!totalFiles) {
                    imgPreview.classList.remove('quote-imgs-thumbs--hidden');
                    previewTitle = document.createElement('p');
                    previewTitle.style.fontWeight = 'bold';
                    previewTitleText = document.createTextNode(totalFiles + ' Total Images Selected');
                    previewTitle.appendChild(previewTitleText);
                    imgPreview.appendChild(previewTitle);
                }

                for (var i = 0; i < totalFiles; i++) {
                    img = document.createElement('img');
                    img.src = URL.createObjectURL(event.target.files[i]);
                    img.classList.add('img-preview-thumb');
                    imgPreview.appendChild(img);
                }
            }
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminPanel/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Android Studio Projects\Wallpaper App For Client Of Aasif\AdminPanel\resources\views/adminPanel/addImages.blade.php ENDPATH**/ ?>