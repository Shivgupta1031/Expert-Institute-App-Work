

<?php $__env->startSection('header'); ?>

    <style>
        .carousel {
            position: relative;
        }

        .carousel-item img {
            object-fit: cover;
        }

        #carousel-thumbs {
            background: rgb(0, 0, 0);
            bottom: 0;
            left: 0;
            padding: 0 50px;
            right: 0;
        }

        #carousel-thumbs img {
            border: 5px solid transparent;
            cursor: pointer;
        }

        #carousel-thumbs img:hover {
            border-color: rgb(255, 255, 255);
        }

        #carousel-thumbs .selected img {
            border-color: #fff;
        }

        iframe {
            border: none;
            background: #000;
        }

        .carousel-control-prev,
        .carousel-control-next {
            width: 50px;
        }

        @media  all and (max-width: 767px) {
            .carousel-container #carousel-thumbs img {
                border-width: 3px;
            }
        }

        @media  all and (min-width: 576px) {
            .carousel-container #carousel-thumbs {
                position: absolute;
            }
        }

        @media  all and (max-width: 576px) {
            .carousel-container #carousel-thumbs {
                background: #ccccce;
            }
        }

        /*jssor slider loading skin double-tail-spin css*/
        .jssorl-004-double-tail-spin img {
            animation-name: jssorl-004-double-tail-spin;
            animation-duration: 1.6s;
            animation-iteration-count: infinite;
            animation-timing-function: linear;
        }

        @keyframes  jssorl-004-double-tail-spin {
            from {
                transform: rotate(0deg);
            }

            to {
                transform: rotate(360deg);
            }
        }

        /*jssor slider bullet skin 031 css*/
        .jssorb031 {
            position: absolute;
        }

        .jssorb031 .i {
            position: absolute;
            cursor: pointer;
        }

        .jssorb031 .i .b {
            fill: #000;
            fill-opacity: 0.6;
            stroke: #fff;
            stroke-width: 1600;
            stroke-miterlimit: 10;
            stroke-opacity: 0.8;
        }

        .jssorb031 .i:hover .b {
            fill: #fff;
            fill-opacity: 1;
            stroke: #000;
            stroke-opacity: 1;
        }

        .jssorb031 .iav .b {
            fill: #fff;
            stroke: #000;
            stroke-width: 1600;
            fill-opacity: .6;
        }

        .jssorb031 .i.idn {
            opacity: .3;
        }

        /*jssor slider arrow skin 051 css*/
        .jssora051 {
            display: block;
            position: absolute;
            cursor: pointer;
        }

        .jssora051 .a {
            fill: none;
            stroke: #fff;
            stroke-width: 360;
            stroke-miterlimit: 10;
        }

        .jssora051:hover {
            opacity: .8;
        }

        .jssora051.jssora051dn {
            opacity: .5;
        }

        .jssora051.jssora051ds {
            opacity: .3;
            pointer-events: none;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div id="bannerCont1">
        <!-- Loading Screen -->
        <div data-u="loading" class="jssorl-004-double-tail-spin"
            style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
            <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;"
                src="<?php echo e(asset('images/double-tail-spin.svg')); ?>" />
        </div>
        <div data-u="slides" id="bannerCont2">
            <?php $__currentLoopData = $data['banners']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <img data-u="image" src="<?php echo e($banner['link']); ?>" />
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div><a data-scale="0" href="https://www.jssor.com" style="display:none;position:absolute;">slider html</a>
        <!-- Bullet Navigator -->
        <div data-u="navigator" class="jssorb031" style="position:absolute;bottom:16px;right:16px;" data-autocenter="1"
            data-scale="0.5" data-scale-bottom="0.75">
            <div data-u="prototype" class="i" style="width:13px;height:13px;">
                <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                    <circle class="b" cx="8000" cy="8000" r="5800"></circle>
                </svg>
            </div>
        </div>
        <!-- Arrow Navigator -->
        <div data-u="arrowleft" class="jssora051" style="width:55px;height:55px;top:0px;left:25px;" data-autocenter="2"
            data-scale="0.75" data-scale-left="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <polyline class="a" points="11040,1920 4960,8000 11040,14080 "></polyline>
            </svg>
        </div>
        <div data-u="arrowright" class="jssora051" style="width:55px;height:55px;top:0px;right:25px;" data-autocenter="2"
            data-scale="0.75" data-scale-right="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <polyline class="a" points="4960,1920 11040,8000 4960,14080 "></polyline>
            </svg>
        </div>
    </div>

    <label id="whyChooseTxt">WHY CHOOSE OM STAR</label>
    <label id="toDeliverTxt">TO DELIVER HIGH-PERFORMING QUALITY PRODUCTS CONSISTENTLY.</label>

    <div class="topIconsContainer">
        <div id="topIconsImgDiv">
            <img src="<?php echo e(asset('images/entertainment.png')); ?>" alt="" id="topIconsImg">
            <label id="topIconsTxt">Entertainment</label>
        </div>
        <div id="topIconsImgDiv">
            <img src="<?php echo e(asset('images/connectshare.png')); ?>" alt="" id="topIconsImg">
            <label id="topIconsTxt">Connect & Share</label>
        </div>
        <div id="topIconsImgDiv" class="center">
            <img src="<?php echo e(asset('images/experience.png')); ?>" alt="" id="topIconsImg">
            <label id="topIconsTxt">Experience</label>
        </div>
        <div id="topIconsImgDiv">
            <img src="<?php echo e(asset('images/process.png')); ?>" alt="" id="topIconsImg">
            <label id="topIconsTxt">Process</label>
        </div>
    </div>

    <div id="product">

        <label id="featuredProductsTxt">Featured Products</label>

        <?php $__empty_1 = true; $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($loop->first): ?>
                <div id="productsConatiner">
            <?php endif; ?>
            <div id="productDiv">
                <div class="flip-card">
                    <img src="<?php echo e($product['thumbnail']); ?>" id="productImg">
                    <div class="flip-card-inner">
                        <div class="flip-card-front">
                        </div>
                        <div class="flip-card-back">
                            <a href="product/<?php echo e($product['id']); ?>">
                                <img src="<?php echo e(asset('images\next.png')); ?>"
                                    style="height: 50px; width: 50px; position: absolute;
                                                                                                                                                                                                                            top: 50%;
                                                                                                                                                                                                                            transform: translate(-50%, -50%);
                                                                                                                                                                                                                            left: 50%;
                                                                                                                                                                                                                            -ms-transform: translate(-50%, -50%);">
                            </a>
                        </div>
                    </div>
                </div>
                <br>
                <label id="productTxt"><?php echo e($product['name']); ?></label>
                <label id="priceTxt">Price <?php echo e($product['price']); ?> INR</label>
                <a href="product/<?php echo e($product['id']); ?>"><button id="button">See Details</button></a>

            </div>
            <?php if($loop->last): ?>
        </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h5 class="text-center mt-4 mb-4">No Featured Products Found</h5>
    <?php endif; ?>
    </div>

    <div>
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <?php $__empty_1 = true; $__currentLoopData = $data['videos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($loop->first): ?>
                        <div class="carousel-item active" data-slide-number="<?php echo e($loop->index); ?>">
                            <iframe src="https://www.youtube.com/embed/<?php echo e($video['video_id']); ?>" height="500px"
                                class="d-block w-100"></iframe>
                        </div>
                    <?php else: ?>
                        <div class="carousel-item" data-slide-number="<?php echo e($loop->index); ?>">
                            <iframe src="https://www.youtube.com/embed/<?php echo e($video['video_id']); ?>" height="500px"
                                class="d-block w-100"></iframe>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="carousel-item active" data-slide-number="0">
                        <video id="video" class="d-block w-100" poster="<?php echo e(asset('thumbnail.jpg')); ?>" controls
                            preload="metadata">
                            <source src="<?php echo e(asset('omstarPromo.mp4')); ?>" type="video/mp4">
                        </video>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div id="carousel-thumbs" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="row mx-0 d-flex justify-content-center">
                        <?php $__empty_1 = true; $__currentLoopData = $data['videos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if($loop->first): ?>
                                <div id="carousel-selector-<?php echo e($loop->index); ?>"
                                    class="thumb col-4 col-sm-2 px-1 py-2 selected" data-target="#myCarousel"
                                    data-slide-to="<?php echo e($loop->index); ?>">
                                    <img src="https://img.youtube.com/vi/<?php echo e($video['video_id']); ?>/mqdefault.jpg"
                                        class="img-fluid" alt="...">
                                </div>
                            <?php else: ?>
                                <div id="carousel-selector-<?php echo e($loop->index); ?>" class="thumb col-4 col-sm-2 px-1 py-2"
                                    data-target="#myCarousel" data-slide-to="<?php echo e($loop->index); ?>">
                                    <img src="https://img.youtube.com/vi/<?php echo e($video['video_id']); ?>/mqdefault.jpg"
                                        class="img-fluid" alt="...">
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div id="carousel-selector-0" class="thumb col-4 col-sm-2 px-1 py-2 selected"
                                data-target="#myCarousel" data-slide-to="0">
                                <img src="<?php echo e(asset('thumbnail.jpg')); ?>" class="img-fluid" alt="...">
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carousel-thumbs" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carousel-thumbs" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>

        </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>

        <script src="<?php echo e(asset('js/jssor.slider-28.0.0.min.js')); ?>" type="text/javascript"></script>
        <script type="text/javascript">
            window.jssor_1_slider_init = function() {

                var jssor_1_SlideoTransitions = [
                    [{
                        b: 500,
                        d: 1000,
                        x: 0,
                        e: {
                            x: 6
                        }
                    }],
                    [{
                        b: -1,
                        d: 1,
                        x: 100,
                        p: {
                            x: {
                                d: 1,
                                dO: 9
                            }
                        }
                    }, {
                        b: 0,
                        d: 2000,
                        x: 0,
                        e: {
                            x: 6
                        },
                        p: {
                            x: {
                                dl: 0.1
                            }
                        }
                    }],
                    [{
                        b: -1,
                        d: 1,
                        x: 200,
                        p: {
                            x: {
                                d: 1,
                                dO: 9
                            }
                        }
                    }, {
                        b: 0,
                        d: 2000,
                        x: 0,
                        e: {
                            x: 6
                        },
                        p: {
                            x: {
                                dl: 0.1
                            }
                        }
                    }],
                    [{
                        b: -1,
                        d: 1,
                        rX: 20,
                        rY: 90
                    }, {
                        b: 0,
                        d: 4000,
                        rX: 0,
                        e: {
                            rX: 1
                        }
                    }],
                    [{
                        b: -1,
                        d: 1,
                        rY: -20
                    }, {
                        b: 0,
                        d: 4000,
                        rY: -90,
                        e: {
                            rY: 7
                        }
                    }],
                    [{
                        b: -1,
                        d: 1,
                        sX: 2,
                        sY: 2
                    }, {
                        b: 1000,
                        d: 3000,
                        sX: 1,
                        sY: 1,
                        e: {
                            sX: 1,
                            sY: 1
                        }
                    }],
                    [{
                        b: -1,
                        d: 1,
                        sX: 2,
                        sY: 2
                    }, {
                        b: 1000,
                        d: 5000,
                        sX: 1,
                        sY: 1,
                        e: {
                            sX: 3,
                            sY: 3
                        }
                    }],
                    [{
                        b: -1,
                        d: 1,
                        tZ: 300
                    }, {
                        b: 0,
                        d: 2000,
                        o: 1
                    }, {
                        b: 3500,
                        d: 3500,
                        tZ: 0,
                        e: {
                            tZ: 1
                        }
                    }],
                    [{
                        b: -1,
                        d: 1,
                        x: 20,
                        p: {
                            x: {
                                o: 33,
                                r: 0.5
                            }
                        }
                    }, {
                        b: 0,
                        d: 1000,
                        x: 0,
                        o: 0.5,
                        e: {
                            x: 3,
                            o: 1
                        },
                        p: {
                            x: {
                                dl: 0.05,
                                o: 33
                            },
                            o: {
                                dl: 0.02,
                                o: 68,
                                rd: 2
                            }
                        }
                    }, {
                        b: 1000,
                        d: 1000,
                        o: 1,
                        e: {
                            o: 1
                        },
                        p: {
                            o: {
                                dl: 0.05,
                                o: 68,
                                rd: 2
                            }
                        }
                    }],
                    [{
                        b: -1,
                        d: 1,
                        da: [0, 700]
                    }, {
                        b: 0,
                        d: 600,
                        da: [700, 700],
                        e: {
                            da: 1
                        }
                    }],
                    [{
                        b: 600,
                        d: 1000,
                        o: 0.4
                    }],
                    [{
                        b: -1,
                        d: 1,
                        da: [0, 400]
                    }, {
                        b: 200,
                        d: 600,
                        da: [400, 400],
                        e: {
                            da: 1
                        }
                    }],
                    [{
                        b: 800,
                        d: 1000,
                        o: 0.4
                    }],
                    [{
                        b: -1,
                        d: 1,
                        sX: 1.1,
                        sY: 1.1
                    }, {
                        b: 0,
                        d: 1600,
                        o: 1
                    }, {
                        b: 1600,
                        d: 5000,
                        sX: 0.9,
                        sY: 0.9,
                        e: {
                            sX: 1,
                            sY: 1
                        }
                    }],
                    [{
                        b: 0,
                        d: 1000,
                        o: 1,
                        p: {
                            o: {
                                o: 4
                            }
                        }
                    }],
                    [{
                        b: 1000,
                        d: 1000,
                        o: 1,
                        p: {
                            o: {
                                o: 4
                            }
                        }
                    }]
                ];

                var jssor_1_options = {
                    $AutoPlay: 1,
                    $CaptionSliderOptions: {
                        $Class: $JssorCaptionSlideo$,
                        $Transitions: jssor_1_SlideoTransitions
                    },
                    $ArrowNavigatorOptions: {
                        $Class: $JssorArrowNavigator$
                    },
                    $BulletNavigatorOptions: {
                        $Class: $JssorBulletNavigator$,
                        $SpacingX: 16,
                        $SpacingY: 16
                    }
                };

                var jssor_1_slider = new $JssorSlider$("bannerCont1", jssor_1_options);

                /*#region responsive code begin*/

                var MAX_WIDTH = 2000;

                function ScaleSlider() {
                    var containerElement = jssor_1_slider.$Elmt.parentNode;
                    var containerWidth = containerElement.clientWidth;

                    if (containerWidth) {

                        var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

                        jssor_1_slider.$ScaleWidth(expectedWidth);
                    } else {
                        window.setTimeout(ScaleSlider, 30);
                    }
                }

                ScaleSlider();

                $Jssor$.$AddEvent(window, "load", ScaleSlider);
                $Jssor$.$AddEvent(window, "resize", ScaleSlider);
                $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
                /*#endregion responsive code end*/
            };

        </script>

        <script type="text/javascript">
            jssor_1_slider_init();

        </script>

        <script type="text/javascript">
            $('#myCarousel').carousel({
                interval: false
            });
            $('#carousel-thumbs').carousel({
                interval: false
            });

            // handles the carousel thumbnails
            // https://stackoverflow.com/questions/25752187/bootstrap-carousel-with-thumbnails-multiple-carousel
            $('[id^=carousel-selector-]').click(function() {
                var id_selector = $(this).attr('id');
                var id = parseInt(id_selector.substr(id_selector.lastIndexOf('-') + 1));
                $('#myCarousel').carousel(id);
            });
            // Only display 3 items in nav on mobile.
            if ($(window).width() < 575) {
                $('#carousel-thumbs .row div:nth-child(4)').each(function() {
                    var rowBoundary = $(this);
                    $('<div class="row mx-0">').insertAfter(rowBoundary.parent()).append(rowBoundary
                        .nextAll()
                        .addBack());
                });
                $('#carousel-thumbs .carousel-item .row:nth-child(even)').each(function() {
                    var boundary = $(this);
                    $('<div class="carousel-item">').insertAfter(boundary.parent()).append(boundary
                        .nextAll()
                        .addBack());
                });
            }
            // Hide slide arrows if too few items.
            if ($('#carousel-thumbs .carousel-item').length < 2) {
                $('#carousel-thumbs [class^=carousel-control-]').remove();
                $('.machine-carousel-container #carousel-thumbs').css('padding', '0 5px');
            }
            // when the carousel slides, auto update
            $('#myCarousel').on('slide.bs.carousel', function(e) {
                var id = parseInt($(e.relatedTarget).attr('data-slide-number'));
                $('[id^=carousel-selector-]').removeClass('selected');
                $('[id=carousel-selector-' + id + ']').addClass('selected');
            });
            // when user swipes, go next or previous
            $('#myCarousel').swipe({
                fallbackToMouseEvents: true,
                swipeLeft: function(e) {
                    $('#myCarousel').carousel('next');
                },
                swipeRight: function(e) {
                    $('#myCarousel').carousel('prev');
                },
                allowPageScroll: 'vertical',
                preventDefaultEvents: false,
                threshold: 75
            });
            /*
            $(document).on('click', '[data-toggle="lightbox"]', function(event) {
              event.preventDefault();
              $(this).ekkoLightbox();
            });
            */

            $('#myCarousel .carousel-item img').on('click', function(e) {
                var src = $(e.target).attr('data-remote');
                if (src) $(this).ekkoLightbox();
            });

        </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\omstar\resources\views/website\home.blade.php ENDPATH**/ ?>