<nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
        <!-- Brand -->
        <div class="sidenav-header  align-items-center">
            <div class="navbar-brand">
                <img src="<?php echo e(asset('images/logo.png')); ?>" class="navbar-brand-img" alt="...">
            </div>
        </div>
        <div class="navbar-inner">
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="sidenav-collapse-main">
                <!-- Nav items -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <?php if($activePage == 'cricket'): ?>
                            <a class="nav-link active" href="<?php echo e(route('cricket')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('cricket')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-gamepad text-primary"></i>
                        <span class="nav-link-text">Cricket</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'football'): ?>
                            <a class="nav-link active" href="<?php echo e(route('football')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('football')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-gamepad text-green"></i>
                        <span class="nav-link-text">Football</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'news'): ?>
                            <a class="nav-link active" href="<?php echo e(route('news')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('news')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-newspaper text-red"></i>
                        <span class="nav-link-text">News</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'tips'): ?>
                            <a class="nav-link active" href="<?php echo e(route('tips')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('tips')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-campground text-primary"></i>
                        <span class="nav-link-text">Tips</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'faq'): ?>
                            <a class="nav-link active" href="<?php echo e(route('faq')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('faq')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-question-circle text-green"></i>
                        <span class="nav-link-text">Faq</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'notification'): ?>
                            <a class="nav-link active" href="<?php echo e(route('notification')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('notification')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-bell text-red"></i>
                        <span class="nav-link-text">Send Notification</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'settings'): ?>
                            <a class="nav-link active" href="<?php echo e(route('settings')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('settings')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-cog text-primary"></i>
                        <span class="nav-link-text">Settings</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH F:\Android Studio Projects\Prem Apps Projects\Dream 11 Guide App\AdminPanel\resources\views/adminPanel/sidemenu.blade.php ENDPATH**/ ?>