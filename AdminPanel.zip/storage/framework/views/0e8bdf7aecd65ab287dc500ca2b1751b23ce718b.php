<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Trumbowyg/2.23.0/ui/trumbowyg.min.css"
        integrity="sha512-iw/TO6rC/bRmSOiXlanoUCVdNrnJBCOufp2s3vhTPyP1Z0CtTSBNbEd5wIo8VJanpONGJSyPOZ5ZRjZ/ojmc7g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="header bg-primary pb-6">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h2 text-white d-inline-block mb-0">Videos</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header border-0">
                        <div id="noticeAlert">
                            <?php if(\Session::has('message')): ?>
                                <?php if(\Session::has('success') && \Session::get('success')): ?>
                                    <div class="alert-success alert alert-dismissible fade show w-100 mr-3"
                                        data-auto-dismiss="3000" role="alert">
                                        <span class="h4 text-white"> <i
                                                class="fas fa-check mr-2"></i><?php echo \Session::get('message'); ?></span>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                                aria-hidden="true">&times;</span></button>
                                    </div>
                                <?php else: ?>
                                    <div class="alert-danger alert alert-dismissible fade show w-100 mr-3"
                                        data-auto-dismiss="3000" role="alert">
                                        <span class="h4 text-white"> <i
                                                class="fas fa-check mr-2"></i><?php echo \Session::get('message'); ?></span>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                                aria-hidden="true">&times;</span></button>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">Videos</h3>
                            </div>
                            <div class="col-lg-6 col-5 text-right">
                                <a class="btn btn-sm btn-primary" href="#" role="button" data-toggle="modal"
                                    data-target="#addVideosItem" aria-haspopup="true" aria-expanded="false">
                                    <i class="fas fa-plus"></i>
                                </a>
                                <div class="modal text-left" id="addVideosItem">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content justify-content-center">
                                            <!-- Modal Header -->
                                            <div class="modal-header">
                                                <h2 class="modal-title">Add Video</h2>
                                                <button type="button" class="close" data-dismiss="modal">
                                                    &times;
                                                </button>
                                            </div>

                                            <!-- Modal body -->
                                            <div class="modal-body model">
                                                <form method="post" action="<?php echo e(route('addVideosItem')); ?>"
                                                    id="img-upload-form" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="form-group">
                                                        <label class="h4" for="title">Title</label>
                                                        <input type="text" class="form-control" id="title"
                                                            name="title" />
                                                    </div>
                                                    <label class="h4">Video Image</label>
                                                    <div class="custom-file">
                                                        <input type="file" class="custom-file" accept="image/*"
                                                            name="image" id="image" />
                                                        <label class="custom-file-label" id="imageName"
                                                            for="image">Choose
                                                            File</label>
                                                    </div>
                                                    <div class="active-pink-3 active-pink-4 mb-2">
                                                        <input type="text" class="form-control" id="imageUrl"
                                                            name="imageUrl" placeholder="Or Enter File Url" />
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="h4" for="url">Video Link</label>
                                                        <input type="text" class="form-control" id="video_link"
                                                            name="video_link" />
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="description">Description</label>
                                                        <textarea class="form-control editor" id="description" name="description"></textarea>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="video_type"><span class="h4">Video
                                                                Type</span></label>
                                                        <select name="video_type" id="video_type" class="custom-select">
                                                            <option selected value="0">Recorded</option>
                                                            <option value="1">Live</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="course_id"><span class="h4">Select
                                                                Course</span></label>
                                                        <select name="course_id" id="course_id" class="custom-select">
                                                            <option selected value="0">Free</option>
                                                            <?php $__empty_1 = true; $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <option value="<?php echo e($item['id']); ?>"><?php echo e($loop->index + 1); ?>.
                                                                    <?php echo e($item['title']); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <option value="0">No Course Found</option>
                                                            <?php endif; ?>
                                                        </select>
                                                    </div>
                                                    <button type="submit"
                                                        class="d-flex justify-content-center input-group btn btn-primary text-center">
                                                        Add Video
                                                    </button>
                                                </form>
                                            </div>

                                            <!-- Modal footer -->
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                                    Close
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive" id="noticeTable">
                        <!-- Projects table -->
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">S.no</th>
                                    <th scope="col">Image</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Video Type</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <span><?php echo e($loop->index + 1); ?></span>
                                        </td>
                                        <td>
                                            <?php if(strlen($item['image']) == 0): ?>
                                                <img class="img-fluid" src="<?php echo e(asset('images/user.png')); ?>"
                                                    width="60px">
                                            <?php else: ?>
                                                <img class="img-fluid rounded" src="<?php echo e($item['image']); ?>" width="120px">
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="text-wrap h4" style="width: 100px">
                                                <span><?php echo e($item['title']); ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if($item['video_type'] == 0): ?>
                                                <span class="success_gradient">RECORDED</span>
                                            <?php else: ?>
                                                <span class="blue_gradient">LIVE</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a class="btn btn-sm btn-primary" href="#" role="button"
                                                data-toggle="modal" data-target="#editVideoItem<?php echo e($item['id']); ?>"
                                                aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a class="btn btn-sm btn-primary text-white"
                                                href="<?php echo e(route('deleteVideosItem')); ?>?id=<?php echo e($item['id']); ?>"
                                                role="button" data-toggle="tooltip" data-placement="top"
                                                title="Delete Video">
                                                <i class="fa fa-trash"></i>
                                            </a>
                                        </td>

                                        <div class="modal text-left" id="editVideoItem<?php echo e($item['id']); ?>">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content justify-content-center">
                                                    <!-- Modal Header -->
                                                    <div class="modal-header">
                                                        <h2 class="modal-title">View Details</h2>
                                                        <button type="button" class="close" data-dismiss="modal">
                                                            &times;
                                                        </button>
                                                    </div>

                                                    <!-- Modal body -->
                                                    <div class="modal-body model">
                                                        <form method="post" action="<?php echo e(route('editVideoItem')); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <input hidden type="text" class="form-control"
                                                                id="id" name="id"
                                                                value="<?php echo e($item['id']); ?>" />
                                                            <div class="form-group">
                                                                <label for="id<?php echo e($item['id']); ?>">Video ID</label>
                                                                <input disabled type="text" class="form-control"
                                                                    id="id<?php echo e($item['id']); ?>"
                                                                    name="id<?php echo e($item['id']); ?>"
                                                                    value="<?php echo e($item['id']); ?>" />
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="title<?php echo e($item['id']); ?>">Title</label>
                                                                <input disabled type="text" class="form-control"
                                                                    id="title<?php echo e($item['id']); ?>"
                                                                    name="title<?php echo e($item['id']); ?>"
                                                                    value="<?php echo e($item['title']); ?>" />
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="course_title<?php echo e($item['id']); ?>">Course</label>
                                                                <?php if($item['course_id'] == 0): ?>
                                                                    <input disabled type="text" class="form-control"
                                                                        id="course_title<?php echo e($item['id']); ?>"
                                                                        value="Free" />
                                                                <?php else: ?>
                                                                    <input disabled type="text" class="form-control"
                                                                        id="course_title<?php echo e($item['id']); ?>"
                                                                        value="<?php echo e($item['course_title']); ?>" />
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="form-group">
                                                                <label
                                                                    for="description<?php echo e($item['id']); ?>">Description</label>
                                                                <textarea disabled class="form-control editor" id="description<?php echo e($item['id']); ?>"
                                                                    name="description<?php echo e($item['id']); ?>"><?php echo e($item['description']); ?></textarea>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="video_link<?php echo e($item['id']); ?>">Video
                                                                    Link</label>
                                                                <input disabled type="text" class="form-control"
                                                                    id="video_link<?php echo e($item['id']); ?>"
                                                                    name="video_link<?php echo e($item['id']); ?>"
                                                                    value="<?php echo e($item['video_link']); ?>" />
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="video_type<?php echo e($item['id']); ?>"><span
                                                                        class="h4">Video type</span></label>
                                                                <select name="video_type<?php echo e($item['id']); ?>"
                                                                    id="video_type<?php echo e($item['id']); ?>"
                                                                    class="custom-select">
                                                                    <?php if($item['video_type'] == 0): ?>
                                                                        <option selected value="0">RECORDED</option>
                                                                        
                                                                    <?php else: ?>
                                                                        
                                                                        <option selected value="1">LIVE</option>
                                                                    <?php endif; ?>
                                                                </select>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="created<?php echo e($item['id']); ?>">Created On</label>
                                                                <input disabled type="text" class="form-control"
                                                                    id="created<?php echo e($item['id']); ?>"
                                                                    name="created<?php echo e($item['id']); ?>"
                                                                    value="<?php echo e($item['created']); ?>" />
                                                            </div>
                                                            
                                                        </form>
                                                    </div>

                                                    <!-- Modal footer -->
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">
                                                            Close
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td>Nothing Found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div id="noticePages" class="card-footer border-0">
                        <div class="row align-items-center align-middle">
                            <div class="col">
                                <?php echo e($data->links('vendor/pagination/bootstrap-4')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('adminPanel.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.js"
        integrity="sha512-n/4gHW3atM3QqRcbCn6ewmpxcLAHGaDjpEBu4xZd47N0W2oQ+6q7oc3PXstrJYXcbNU1OHdQ1T7pAP+gi5Yu8g=="
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.3.0/jquery.form.js"
        integrity="sha512-RTxmGPtGtFBja+6BCvELEfuUdzlPcgf5TZ7qOVRmDfI9fDdX2f1IwBq+ChiELfWt72WY34n0Ti1oo2Q3cWn+kw=="
        crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Trumbowyg/2.23.0/trumbowyg.min.js"
        integrity="sha512-sffB9/tXFFTwradcJHhojkhmrCj0hWeaz8M05Aaap5/vlYBfLx5Y7woKi6y0NrqVNgben6OIANTGGlojPTQGEw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        $(function() {
            $('.editor').trumbowyg();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminPanel/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Android_Studio_Projects\Awari Academy App Fiverr Client\AdminPanel\resources\views/adminPanel/videos.blade.php ENDPATH**/ ?>