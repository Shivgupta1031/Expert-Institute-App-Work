

<?php $__env->startSection('css'); ?>
    <style>
        @media (min-width: 200px) and (max-width: 420px) {

            .btn-sm,
            .btn {
                font-size: 0.75rem;
                line-height: 1.5;
                padding: 0.1rem 0.3rem;
                border-radius: 0.25rem;
            }

            .btn:not(:last-child) {
                margin-right: 0.2rem;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="header bg-primary pb-6">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h2 text-white d-inline-block mb-0">Settings</h6>
                    </div>
                </div>
                <div id="noticeAlert">
                    <?php if(\Session::has('message')): ?>
                        <?php if(\Session::has('success') && \Session::get('success')): ?>
                            <div class="alert-success alert alert-dismissible fade show w-100 mr-3" data-auto-dismiss="3000"
                                role="alert">
                                <span class="h4 text-white"> <i class="fas fa-check mr-2"></i><?php echo \Session::get('message'); ?></span>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                        aria-hidden="true">&times;</span></button>
                            </div>
                        <?php else: ?>
                            <div class="alert-danger alert alert-dismissible fade show w-100 mr-3" data-auto-dismiss="3000"
                                role="alert">
                                <span class="h4 text-white"> <i class="fas fa-check mr-2"></i><?php echo \Session::get('message'); ?></span>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                        aria-hidden="true">&times;</span></button>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-xl-12 mt-7">
                <form method="post" action="<?php echo e(route('saveSettings')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="h3" for="url">Whatsapp Number</label>
                        <input type="text" class="form-control" id="whatsapp_number" name="whatsapp_number" value="<?php echo e($data['whatsapp_number']); ?>"/>
                    </div>
                    <div class="form-group">
                        <label class="h3" for="url">Telegram Link</label>
                        <input type="text" class="form-control" id="telegram_link" name="telegram_link" value="<?php echo e($data['telegram_link']); ?>"/>
                    </div>
                    <div class="form-group">
                        <label class="h3" for="url">Instagram Link</label>
                        <input type="text" class="form-control" id="instagram_link" name="instagram_link" value="<?php echo e($data['instagram_link']); ?>"/>
                    </div>
                    <div class="form-group">
                        <label class="h3" for="url">Facebook Link</label>
                        <input type="text" class="form-control" id="facebook_link" name="facebook_link" value="<?php echo e($data['facebook_link']); ?>" />
                    </div>
                    <div class="form-group">
                        <label class="h3" for="url">Share App Message</label>
                        <input type="text" class="form-control" id="share_message" name="share_message" value="<?php echo e($data['share_message']); ?>" />
                    </div>
                    <button type="submit" class="btn btn-primary">Save</button>
                </form>
            </div>
        </div>

        <?php echo $__env->make('adminPanel.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminPanel/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Android_Studio_Projects\Awari Academy App Fiverr Client\AdminPanel\resources\views/adminPanel/settings.blade.php ENDPATH**/ ?>