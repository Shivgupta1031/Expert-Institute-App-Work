<nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
        <!-- Brand -->
        <div class="sidenav-header  align-items-center">
            <div class="navbar-brand">
                <img src="<?php echo e(asset('images/logo.png')); ?>" class="navbar-brand-img" alt="...">
            </div>
        </div>
        <div class="navbar-inner">
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="sidenav-collapse-main">
                <!-- Nav items -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <?php if($activePage == 'imagesList'): ?>
                            <a class="nav-link active" href="/adminpanel/panel/home/imagesList/">
                            <?php else: ?>
                                <a class="nav-link" href="/adminpanel/panel/home/imagesList/">
                        <?php endif; ?>
                        <i class="fas fa-images text-primary"></i>
                        <span class="nav-link-text">Images</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'withdrawals'): ?>
                            <a class="nav-link active" href="/adminpanel/panel/home/withdrawals/">
                            <?php else: ?>
                                <a class="nav-link" href="/adminpanel/panel/home/withdrawals/">
                        <?php endif; ?>
                        <i class="fas fa-hand-holding-usd text-green"></i>
                        <span class="nav-link-text">Withdrawals</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'settings'): ?>
                            <a class="nav-link active" href="/adminpanel/panel/home/settings/">
                            <?php else: ?>
                                <a class="nav-link" href="/adminpanel/panel/home/settings/">
                        <?php endif; ?>
                        <i class="fas fa-cog text-black"></i>
                        <span class="nav-link-text">Settings</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'addImage'): ?>
                            <a class="nav-link active" href="/adminpanel/panel/home/addImage/">
                            <?php else: ?>
                                <a class="nav-link" href="/adminpanel/panel/home/addImage/">
                        <?php endif; ?>
                        <i class="fas fa-plus-square text-red"></i>
                        <span class="nav-link-text">Add Images</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH D:\Android Studio Projects\Wallpaper App For Client Of Aasif\AdminPanel\resources\views/adminPanel/sidemenu.blade.php ENDPATH**/ ?>