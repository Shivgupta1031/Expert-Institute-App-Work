<footer class="footer mt-4 pt-0">
    <div class="row align-items-center justify-content-lg-between">
        <div class="col-lg-6">
            <div class="copyright text-center  text-lg-left  text-muted">
                &copy; 2021 <?php echo e(env('APP_NAME')); ?>

            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\Android_Studio_Projects\Awari Academy App Fiverr Client\AdminPanel\resources\views/adminPanel/footer.blade.php ENDPATH**/ ?>