<nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
        <!-- Brand -->
        <div class="sidenav-header align-items-center">
            <div class="navbar-brand">
                <img src="<?php echo e(asset('images/logo.png')); ?>" class="navbar-brand-img rounded" alt="...">
            </div>
        </div>
        <div class="navbar-inner">
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="sidenav-collapse-main">
                <!-- Nav items -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <?php if($activePage == 'users'): ?>
                            <a class="nav-link active" href="<?php echo e(route('users')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('users')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-users text-primary"></i>
                        <span class="nav-link-text">Users</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'paidCourses'): ?>
                            <a class="nav-link active" href="<?php echo e(route('paidCourses')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('paidCourses')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-sheet-plastic text-yellow"></i>
                        <span class="nav-link-text">Paid Courses</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'ebooks'): ?>
                            <a class="nav-link active" href="<?php echo e(route('ebooks')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('ebooks')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-book text-orange"></i>
                        <span class="nav-link-text">Ebooks</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'banners'): ?>
                            <a class="nav-link active" href="<?php echo e(route('banners')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('banners')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-images text-green"></i>
                        <span class="nav-link-text">Banners</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'syllabus'): ?>
                            <a class="nav-link active" href="<?php echo e(route('syllabus')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('syllabus')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-book-open text-primary"></i>
                        <span class="nav-link-text">Syllabus</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'videos'): ?>
                            <a class="nav-link active" href="<?php echo e(route('videos')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('videos')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-video text-yellow"></i>
                        <span class="nav-link-text">Videos</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'notification'): ?>
                            <a class="nav-link active" href="<?php echo e(route('notification')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('notification')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-bell text-orange"></i>
                        <span class="nav-link-text">Send Notification</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'web_admins'): ?>
                            <a class="nav-link active" href="<?php echo e(route('web_admins')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('web_admins')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-person-chalkboard text-green"></i>
                        <span class="nav-link-text">Web Admins</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'app_settings'): ?>
                            <a class="nav-link active" href="<?php echo e(route('app_settings')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('app_settings')); ?>">
                        <?php endif; ?>
                        <i class="fas fa-cog text-primary"></i>
                        <span class="nav-link-text">App Settings</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'logout'): ?>
                            <a class="nav-link active" href="<?php echo e(route('logout')); ?>">
                            <?php else: ?>
                                <a class="nav-link" href="<?php echo e(route('logout')); ?>">
                        <?php endif; ?>
                        <i class="fa-solid fa-right-from-bracket text-red"></i>
                        <span class="nav-link-text">Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH D:\Android_Studio_Projects\Awari Academy App Fiverr Client\AdminPanel\resources\views/adminPanel/sidemenu.blade.php ENDPATH**/ ?>