<nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
        <!-- Brand -->
        <div class="sidenav-header  align-items-center">
            <div class="navbar-brand">
                <img src="<?php echo e(asset('images/logo.png')); ?>" class="navbar-brand-img" alt="...">
            </div>
        </div>
        <div class="navbar-inner">
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="sidenav-collapse-main">
                <!-- Nav items -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <?php if($activePage == 'productsList'): ?>
                            <a class="nav-link active" href="/omstar/admin/omstar/home/productsList/">
                            <?php else: ?>
                                <a class="nav-link" href="/omstar/admin/omstar/home/productsList/">
                        <?php endif; ?>
                        <i class="fas fa-cart-plus text-primary"></i>
                        <span class="nav-link-text">Products</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'categoriesList'): ?>
                            <a class="nav-link active" href="/omstar/admin/omstar/home/categoriesList/">
                            <?php else: ?>
                                <a class="nav-link" href="/omstar/admin/omstar/home/categoriesList/">
                        <?php endif; ?>
                        <i class="fas fa-list-alt text-orange"></i>
                        <span class="nav-link-text">Categories</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'bannersList'): ?>
                            <a class="nav-link active" href="/omstar/admin/omstar/home/bannersList/">
                            <?php else: ?>
                                <a class="nav-link" href="/omstar/admin/omstar/home/bannersList/">
                        <?php endif; ?>
                        <i class="fas fa-images text-green"></i>
                        <span class="nav-link-text">Banners</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'videosList'): ?>
                            <a class="nav-link active" href="/omstar/admin/omstar/home/videosList/">
                            <?php else: ?>
                                <a class="nav-link" href="/omstar/admin/omstar/home/videosList/">
                        <?php endif; ?>
                        <i class="fas fa-video text-indigo"></i>
                        <span class="nav-link-text">Videos</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if($activePage == 'addProduct'): ?>
                            <a class="nav-link active" href="/omstar/admin/omstar/home/addProduct/">
                            <?php else: ?>
                                <a class="nav-link" href="/omstar/admin/omstar/home/addProduct/">
                        <?php endif; ?>
                        <i class="fas fa-plus-square text-red"></i>
                        <span class="nav-link-text">Add Product</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH D:\Laravel\omstar\resources\views/adminPanel/sidemenu.blade.php ENDPATH**/ ?>