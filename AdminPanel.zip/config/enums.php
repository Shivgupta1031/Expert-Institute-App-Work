<?php

return [
    // For Payment Model
    'RAZORPAY' => 0,
    'PHONE_PE' => 1,
    'MANUAL_PAYMENT' => 2,

    // For User Orders Model
    'PAID_COURSE_ORDER' => 0,
    'EBOOK_ORDER' => 1,
    'MOCK_TEST_CATEGORY_ORDER' => 2,
    'MOCK_TEST_ORDER' => 8,
];
